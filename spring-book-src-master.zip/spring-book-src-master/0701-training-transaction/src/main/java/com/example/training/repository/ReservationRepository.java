package com.example.training.repository;

import com.example.training.entity.Reservation;

public interface ReservationRepository {
	void insert(Reservation reservation);
}
