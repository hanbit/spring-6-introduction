package com.example.training.service;

public interface AuditLogService {

    void registerLog(String functionName);
}
