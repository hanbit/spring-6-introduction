package com.example.shopping.enumeration;

public enum PaymentMethod {
    BANK, CONVENIENCE_STORE
}