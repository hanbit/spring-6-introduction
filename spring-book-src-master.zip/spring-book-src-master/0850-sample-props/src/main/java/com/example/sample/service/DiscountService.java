package com.example.sample.service;

public interface DiscountService {
    int calculateDiscountPrice(int originalPrice);
}
