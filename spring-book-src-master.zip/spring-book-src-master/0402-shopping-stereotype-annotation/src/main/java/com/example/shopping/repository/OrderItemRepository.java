package com.example.shopping.repository;

import com.example.shopping.entity.OrderItem;

public interface OrderItemRepository {
    void insert(OrderItem orderItem);
}
